#pragma once

#include "stdafx.h"
#include<thread>
#include <stdio.h>
#include <tchar.h>
#include <string>
#include <winsock2.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <future>
#include <Ws2tcpip.h>
#include <regex>

#include <types/memory.hpp>
#include <archives/portable_binary.hpp>
#include <archives/xml.hpp>