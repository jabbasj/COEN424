#include "protocol.h"



my_MSG protocol::form_request(int product_num, std::string product_cat, int qty) {

	my_MSG msg;

	msg.type = "RFQ";
	msg.id = getId();
	msg.name = client_info->MY_NAME;
	msg.addr = client_info->SERVER_ADDRESS;
	msg.port = client_info->SERVER_PORT;
	
	msg.request.account_id = client_info->ACCOUNT_ID;
	msg.request.product_number = product_num;
	msg.request.product_category = product_cat;
	msg.request.quantity = qty;

	new_msg(msg); //expect a response

	return msg;
}


my_MSG protocol::ack(my_MSG msg) {

	msg.type = "ACK";
	return msg;
}


//push message for which we expect reply and defragmenting
void protocol::new_msg(my_MSG msg) {
	mut_msgs.lock();

	messages_pending_reply.push_back(msg);
	last_message = getId();

	mut_msgs.unlock();
}


//remove messages older than 30 seconds.
bool protocol::cleanup() {

	mut_msgs.lock();
	bool something_erased = false;
	std::vector<my_MSG>::iterator it = messages_pending_reply.begin();

	while (it != messages_pending_reply.end()) {

		if ((last_message - it->id) > 30000) {

			it = messages_pending_reply.erase(it);
			something_erased = true;
		}
		else { ++it; }
	}
	mut_msgs.unlock();

	return something_erased;
}



void protocol::erase_all() {

	mut_msgs.lock();
	messages_pending_reply.clear();
	mut_msgs.unlock();

}


//returns messages that are 10 seconds old
std::vector<my_MSG> protocol::timed_out_msgs() {
	mut_msgs.lock();

	std::vector<my_MSG>::iterator it = messages_pending_reply.begin();
	std::vector<my_MSG> to_resend;

	int current_time = getId();

	while (it != messages_pending_reply.end()) {

		if ((current_time - it->id) > 10000) {
			to_resend.push_back(*it);
		}
		it++;
	}
	mut_msgs.unlock();

	return to_resend;
}


//get message replied to
//cleans up
//returns msg with ID = 0 if no replies found
my_MSG protocol::replied_to(my_MSG msg) {
	my_MSG reply_to = msg;
	reply_to.id = 0;
	mut_msgs.lock();
	for (size_t i = 0; i < messages_pending_reply.size(); i++) {
		if (msg.id == messages_pending_reply[i].id) {

			reply_to = messages_pending_reply[i];
			messages_pending_reply.erase(messages_pending_reply.begin() + i);
			break;
		}
	}
	mut_msgs.unlock();

	return reply_to;
}


bool protocol::replied(my_MSG msg) {
	my_MSG temp = replied_to(msg);

	if (temp.id != 0) {
		return true;
	}
	return false;
}


my_MSG protocol::error(my_MSG msg , std::string message) {

	my_MSG error_msg;

	error_msg.type = "ERROR";
	error_msg.id = msg.id;
	error_msg.name = client_info->MY_NAME;
	error_msg.addr = msg.addr;
	error_msg.port = msg.port;
	error_msg.message = message;


	return error_msg;
}