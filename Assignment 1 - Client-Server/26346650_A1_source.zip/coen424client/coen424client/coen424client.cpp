#include "allheaders.h"
#include "protocol.h"

//TODO: error handling
//TODO: periodically go over messages_received: erase old ones and send error msg to sender
//TODO: protocol error tolerance, i.e. if contents dmg ask for resend (currently assuming reply has correct contents)

#define BUFLEN 1024  //Max length of buffer
#define START_PORT 10000

void printMsg(my_MSG MSGPacket);

client_status client_info;
protocol *	protocol_manager;

std::vector<my_MSG> messages_to_send;
std::vector<my_MSG> messages_received;	// to do, cleanup old messages
std::vector<my_MSG> temp;				// temp holder for messages_to_send
std::mutex			mut_send;			// mutex for temp (which is a holder for messages_to_send)
std::mutex			mut_recv;			// mutex for messages_received 
std::mutex			mut_friends;

// My functions
void loadServersList();
void initializeConnection();
void listener();
void sender();
void send(my_MSG);
void send(std::vector<my_MSG> msgs);
void receive(my_MSG msg);
void resend_old_messages();
void erase_ignored_messages();
my_MSG deserialize(char* to_deserialize);
void serialize(char* result, my_MSG to_serialize);
void message_handler(my_MSG);
void cleanup();


// UI
void myInterface();
void RequestSerializationType();
void create_RFQ(); //get request info from user and send
void receive_RFP(my_MSG msg);
void setTitle();


// Socket structs
struct sockaddr_in client, si_send, si_recv;
int slen, recv_len;
SOCKET s;
char buf[BUFLEN];
char message[BUFLEN];
WSADATA wsa;

BOOL WINAPI ConsoleCtrlEventHandler(DWORD dwCtrlType);

int _tmain(int argc, _TCHAR* argv[])
{
	try {

		SetConsoleCtrlHandler(&ConsoleCtrlEventHandler, TRUE);
		client_info.MY_PORT = START_PORT;
		protocol_manager = new protocol(&client_info);

		initializeConnection(); // Initialize winsock, create socket, load server list

		std::thread l(listener);
		std::thread s(sender);
		std::async(resend_old_messages);
		std::async(erase_ignored_messages);
		myInterface();
		l.join();
		s.join();
	}
	catch (std::exception e) {
		printf(e.what());
		system("pause");
	}

	cleanup();
	return 0;
}



void myInterface() {

	printf("\nEnter your name:\n");
	std::getline(std::cin, client_info.MY_NAME);

	setTitle();

	//Enter account ID
	std::string acc_id;
	bool acc_id_success = false;

	while (!acc_id_success) {
		try {
			printf("Enter your account ID:\n");
			std::getline(std::cin, acc_id);

			client_info.ACCOUNT_ID = stoi(acc_id);

			acc_id_success = true;
		}
		catch (...) {
			std::cout << "Wrong input!\n";
			acc_id = "";
		}
	}

	setTitle();

	//Options
	std::string input = "";
	while (1) {
		std::cout << "\nSelect option (1: RFQ, 2: Change Serialization, end: Close application): \n";
		try {
			std::getline(std::cin, input);

			if (input == "end") {
				exit(0);
			}

			switch (stoi(input)) {
				case 1:
					create_RFQ();
					break;

				case 2:
					RequestSerializationType();
					break;

				default:
					std::cout << "Invalid option.\n";
			}
		}
		catch (...) {
			std::cout << "Wrong input!\n";
			input = "";
		}
	}
}


//sends all messages in temp vector, todo: change name temp
void sender() {

	while (1)
	{
		if (temp.size() > 0) {

			//printf("Sending (%d) pending messages...\n", temp.size());

			mut_send.lock();
			messages_to_send = temp;
			temp.clear();
			mut_send.unlock();
		}

		while (messages_to_send.size() > 0) {

			my_MSG msg_to_send = messages_to_send.front();

			//reply to sender
			std::wstring stemp = std::wstring(msg_to_send.addr.begin(), msg_to_send.addr.end());
			LPCWSTR sw = stemp.c_str();

			InetPton(AF_INET, sw, &si_send.sin_addr);
			si_send.sin_addr.S_un.S_addr = inet_addr(msg_to_send.addr.c_str());
			si_send.sin_port = htons(msg_to_send.port);

			msg_to_send.name = client_info.MY_NAME;
			msg_to_send.addr = client_info.MY_ADDRESS;
			msg_to_send.port = client_info.MY_PORT;

			serialize(message, msg_to_send);

			//printMsg(msg_to_send);

			if (sendto(s, message, BUFLEN, 0, (struct sockaddr*) &si_send, slen) == SOCKET_ERROR)
			{
				printf("sendto() failed with error code : %d\n", WSAGetLastError());
			}
			messages_to_send.erase(messages_to_send.begin());

			Sleep(10); //Give time for receiver to process
		}
	}
}


//listens to all messages & pushes them to messages_received
void listener() {

	while (1) {

		//printf("Waiting for data...\n");

		//clear the buffer by filling null, it might have previously received data
		memset(buf, '\0', BUFLEN);


		//try to receive some data, this is a blocking call
		if ((recv_len = recvfrom(s, buf, BUFLEN, 0, (struct sockaddr *) &si_recv, &slen)) == SOCKET_ERROR)
		{
			printf("recvfrom() failed with error code : %d\n", WSAGetLastError());
		}

		if (recv_len > 0) {	
			my_MSG received_packet;
			received_packet = deserialize(buf);
			
			received_packet.addr = inet_ntoa(*(struct in_addr *)&si_recv.sin_addr); //use ip from packet instead of given one because external Ip not working on local machine

			//printf("\nReceived packet from %s:%d\n", inet_ntoa(si_recv.sin_addr), ntohs(si_recv.sin_port));
			//printMsg(received_packet);

			std::thread mh(message_handler, received_packet);
			mh.detach();
		}
	}
}

void RequestSerializationType() {

	std::string type = "";
	client_info.SERIAL_TYPE = undefined;

	while (client_info.SERIAL_TYPE == undefined) {
		std::cout << "Select serialization type (1: Binary, 2: XML): \n";
		try {
			std::getline(std::cin, type);

			switch (stoi(type)) {
			case 1:
				client_info.SERIAL_TYPE = binary;
				client_info.SERVER_PORT = client_info.SERVER_PORT_BINARY;
				break;
			case 2:
				client_info.SERIAL_TYPE = xml;
				client_info.SERVER_PORT = client_info.SERVER_PORT_XML;
				break;
			default:
				std::cout << "Invalid option.\n";
			}
		}
		catch (...) {
			std::cout << "Wrong input!\n";
			type = "";
		}
	}

	setTitle();
}


//Handles messages first
void message_handler(my_MSG recv_msg) {

	if (recv_msg.type == "RFP") {

		std::thread rcm(receive_RFP, recv_msg);
		rcm.detach();

	}
	else if (recv_msg.type == "ERROR") {
		if (protocol_manager->replied(recv_msg)) {

			std::cout << "\nERROR::" << recv_msg.message << "\n";
			std::cout << "Original RFQ: Category::" << recv_msg.request.product_category << " -- " << "Product #::" << recv_msg.request.product_number << " -- " << "qty::" << recv_msg.request.quantity << std::endl;

		}
		else {
			send(protocol_manager->error(recv_msg, "UNEXPECTED ERROR"));
		}
	}
	else {
		send(protocol_manager->error(recv_msg, "UNEXPECTED TYPE"));
	}
}


//Asks user for message and sends it to friend, accepts large messages
void create_RFQ() {
	std::string product_category;
	std::string product_number;
	std::string quantity;

	int qty, product_num = -1;

	bool complete = false;

	while (!complete) {

		try {
			std::cout << "================================================================================\n";
			std::cout << "ENTER Request Info for (" << client_info.SERVER_ADDRESS << ":" << client_info.SERVER_PORT << "): \n";
			std::cout << "Product Category: ";
			std::getline(std::cin, product_category);

			std::cout << "Product Number: ";
			std::getline(std::cin, product_number);
			product_num = stoi(product_number);

			std::cout << "Quantity: ";
			std::getline(std::cin, quantity);
			qty = stoi(quantity);
			std::cout << "================================================================================";

			complete = true;
		}
		catch (...) {
			product_category = product_number = quantity = "";
			std::cout << "Wrong Input!\n";
		}

	}

	my_MSG to_send = protocol_manager->form_request(product_num, product_category, qty);
	send(to_send);

	std::cout << "RFQ sent!\n";
}


void receive_RFP(my_MSG RFP) {

	my_MSG RFQ = protocol_manager->replied_to(RFP); //check if this RFP is a reply to my RFQ

	if (RFQ.id == 0) { //check if this RFP corresponds to a RFQ
		send(protocol_manager->error(RFP, "UNEXPECTED RFP"));
	}
	else {

		std::cout << "================================================================================\n";
		std::cout << "RESPONSE FOR PRICE\n";
		std::cout << "Original RFQ: Category::" << RFQ.request.product_category << " -- " << "Product #::" << RFQ.request.product_number << " -- " << "qty::" << RFQ.request.quantity << std::endl;
		std::cout << "Response::" << std::endl;
		std::cout << "Unit price:" << RFP.response.unit_price << " -- " << "Price valid period:" << RFP.response.price_valid_period << std::endl;
		std::cout << "================================================================================\n";

		/* Server doesn't care
		my_MSG reply = protocol_manager->ack(RFP); //acknowledge receipt
		send(reply);*/
	}
}



//initializes socket & related structures
//tries MY_PORT, keeps incrementing by 1 until it succeeds bind
void initializeConnection() {

	slen = sizeof(si_send);

	//Initialise winsock
	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		exit(EXIT_FAILURE);
	}
	printf("Initialised.\n");

	//create socket
	if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == SOCKET_ERROR)
	{
		printf("socket() failed with error code : %d", WSAGetLastError());
		exit(EXIT_FAILURE);
	}

	//load server addr/port
	loadServersList();
	if (client_info.SERVER_ADDRESS == "" || client_info.SERVER_PORT_XML == -1 || client_info.SERVER_PORT_BINARY == -1) {
		printf("Error reading server addr/port\n");
		exit(EXIT_FAILURE);
	}

	//Select serialization type to use
	RequestSerializationType();

	//setup address structure
	memset((char *)&si_send, 0, sizeof(si_send));
	si_send.sin_family = AF_INET;
	si_send.sin_port = htons(client_info.SERVER_PORT);
	si_send.sin_addr.S_un.S_addr = inet_addr(client_info.SERVER_ADDRESS.c_str());

	//Prepare the sockaddr_in structure
	client.sin_family = AF_INET;
	client.sin_addr.s_addr = INADDR_ANY;

	int i = 0;
	int err = SOCKET_ERROR;

	std::cout << "Binding...";
	//TODO: Try random port??? & save it locally???
	//Different port for chatting ???
	//Let user enter port ???
	do {
		client.sin_port = htons(client_info.MY_PORT + i);

		//Bind
		if (err = bind(s, (struct sockaddr *)&client, sizeof(client)))
		{
			printf("Bind failed with error code : %d\n", WSAGetLastError());
			i++;
		}
		
	} while (err == SOCKET_ERROR);
	client_info.MY_PORT = client_info.MY_PORT + i;
	std::cout<< "Bind done.\n";

	std::cout << "Client loaded on port: " << client_info.MY_PORT << "\n";
	std::cout << "Target server: " << client_info.SERVER_ADDRESS << ":" << client_info.SERVER_PORT << "\n";

	//int iTimeout = 3000;
	//setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char *)&iTimeout, sizeof(iTimeout));
}


//read server to use from "serverconfig.txt"
void loadServersList() {

	std::ifstream input_file("serverconfig.txt");

	std::string line;
	if (input_file.is_open()) {

		getline(input_file, line);

		client_info.SERVER_PORT_XML = std::stoi(line.substr(line.find("xml_port:") + std::strlen("xml_port:"), -1));
		client_info.SERVER_PORT_BINARY = std::stoi(line.substr(line.find("binary_port:") + std::strlen("binary_port:"), line.find(",xml_port:") - line.find("binary_port:") - std::strlen("binary_port:")));
		client_info.SERVER_ADDRESS = line.substr(line.find("ip:") + std::strlen("ip:"), line.find(",binary_port") - line.find("ip:") - std::strlen("ip:"));

		input_file.close();
	}
}


//locks mut_send ,pushes message into queue to be sent
void send(my_MSG msg) {
	mut_send.lock();
	temp.push_back(msg);
	mut_send.unlock();
}

//locks mut_send, pushes multiple msgs into queue
void send(std::vector<my_MSG> msgs) {
	mut_send.lock();
	for (size_t i = 0; i < msgs.size(); i++) {
		temp.push_back(msgs[i]);
	}
	mut_send.unlock();
}


void receive(my_MSG msg) {
	mut_recv.lock();
	messages_received.push_back(msg);
	mut_recv.unlock();
}


//resends messages that haven't been replied to for over 10 seconds
void resend_old_messages() {
	std::vector<my_MSG> timed_out;

	auto start = std::chrono::system_clock::now();

	while (1) {
		
		timed_out = protocol_manager->timed_out_msgs();

		if (timed_out.size() > 0) {
			std::cout << "\nResending (" << timed_out.size() << ") following timed out messages:\n";
		}
		for (size_t i = 0; i < timed_out.size(); i++) {
			printMsg(timed_out[i]);
			send(timed_out[i]);
		}

		Sleep(10000);
		start = std::chrono::system_clock::now();
	}
}


//erase messages older than 30 seconds
void erase_ignored_messages() {
	std::vector<my_MSG> ignored;

	auto start = std::chrono::system_clock::now();

	while (1) {

		if (protocol_manager->cleanup()) {
			//Shouldn't happen
			std::cout << "NOTE: IGNORED MESSAGES ERASED...\n";
		}

		Sleep(30000);
		start = std::chrono::system_clock::now();
	}
}


//cout my_MSG
void printMsg(my_MSG msgPacket)
{
	std::cout << "type::" << msgPacket.type << std::endl;
	std::cout << "id::" << msgPacket.id << std::endl;
	std::cout << "port::" << msgPacket.port << std::endl;
	std::cout << "addr::" << msgPacket.addr << std::endl;
	std::cout << "name::" << msgPacket.name << std::endl;

	if (msgPacket.type == "ERROR") {
		std::cout << "msg::" << msgPacket.message << std::endl;
	}

	if (msgPacket.type == "RFP") {
		std::cout << "unit_price::" << msgPacket.response.unit_price << " -- " << "price_valid_period::" << msgPacket.response.price_valid_period << std::endl;
	}

	if (msgPacket.type == "RFQ") {
		std::cout << "acc_id::" << msgPacket.request.account_id << " -- " << "product_category::" << msgPacket.request.product_category << " -- " << "product_#::" << msgPacket.request.product_number << " -- " << "qty::" << msgPacket.request.quantity  << std::endl;
	}
}



//deserialize given buffer into a my_MSG
my_MSG deserialize(char* to_deserialize) {

	my_MSG result;

	try {

		if (client_info.SERIAL_TYPE == xml) {

			std::stringstream ss; // any stream can be used	
			ss.write(to_deserialize, BUFLEN);

			cereal::XMLInputArchive iarchive(ss);// Create an output archive

			iarchive(result);

		}
		else { //default to binary

			std::stringstream ss; // any stream can be used	
			ss.write(to_deserialize, BUFLEN);

			cereal::PortableBinaryInputArchive iarchive(ss);// Create an output archive

			iarchive(result);
		}

	}
	catch (std::exception e) {
		throw e;
		return result;
	}

	return result;
}


//serialize a my_MSG into a buffer
void serialize(char* result, my_MSG to_serialize) {

	try {

		if (client_info.SERIAL_TYPE == xml) {

			std::stringstream ss; // any stream can be used	
			{
				cereal::XMLOutputArchive  oarchive(ss);// Create an output archive

				oarchive(to_serialize);
			}

			ss.read(result, BUFLEN);
		}
		else { //default to binary

			std::stringstream ss; // any stream can be used	
			cereal::PortableBinaryOutputArchive oarchive(ss);// Create an output archive

			oarchive(to_serialize);

			ss.read(result, BUFLEN);

		}
	}
	catch (std::exception e) {
		throw e;
	}
}

void cleanup() {
	closesocket(s);
	WSACleanup();
}

void setTitle() {

	//Set title
	std::string title = "Client: " + client_info.MY_NAME + " (Port: " + std::to_string(client_info.MY_PORT) + ")";
	title += " Account ID: " + std::to_string(client_info.ACCOUNT_ID);
	title += " - Target server: " + client_info.SERVER_ADDRESS + ":" + std::to_string(client_info.SERVER_PORT);
	title += " - Serialization: ";

	if (client_info.SERIAL_TYPE == xml)  {
		title += "XML";
	}
	else if (client_info.SERIAL_TYPE == binary) {
		title += "Binary";
	}
	else {
		title += "UNDEFINED!";
	}
	SetConsoleTitle(std::wstring(title.begin(), title.end()).c_str());

}


BOOL WINAPI ConsoleCtrlEventHandler(DWORD dwCtrlType)
{
	switch (dwCtrlType)
	{
	case CTRL_C_EVENT:
		cleanup();
		return FALSE;
	case CTRL_BREAK_EVENT:
		cleanup();
		// Do nothing.
		// To prevent other potential handlers from
		// doing anything, return TRUE instead.
		return FALSE;

	case CTRL_CLOSE_EVENT:
		cleanup();
		//MessageBox(NULL, L"You clicked the 'X' in the console window! Ack!", L"I'm melting!", MB_OK | MB_ICONINFORMATION);
		return FALSE;

	case CTRL_LOGOFF_EVENT:
		cleanup();
		return FALSE;
	case CTRL_SHUTDOWN_EVENT:
		// Please be careful to read the implications of using
		// each one of these, and the applicability to your
		// code. Unless you are writing a Windows Service,
		// chances are you only need to pay attention to the
		// CTRL_CLOSE_EVENT type.
		cleanup();
		return FALSE;
	}
	cleanup();
	// If it gets this far (it shouldn't), do nothing.
	return FALSE;
}