#include "allheaders.h"

//structs to be serialized/deserialized
struct RFQ //request for quote
{
	int			account_id = -1;
	int			product_number = -1;
	std::string product_category = "";
	int			quantity = -1;

	template <class Archive>
	void serialize(Archive & ar)
	{
		ar(account_id, product_number, product_category, quantity);
	}
};

struct RFP //response for price
{
	float		unit_price = -1; //assumed to be in canadian dollars
	std::string	price_valid_period = "";

	template <class Archive>
	void serialize(Archive & ar)
	{
		ar(unit_price, price_valid_period);
	}
};

struct my_MSG
{
	std::string type = "";
	int			id = -1;
	int			port = -1;
	std::string addr = "";
	std::string name = "";
	std::string message = "";

	RFQ			request;
	RFP			response;

	template <class Archive>
	void serialize(Archive & ar)
	{
		ar(type, id, port, addr, name, message, request, response);
	}
};

enum SERIALIZATION_TYPE { xml, binary, undefined };

struct server_status
{
	std::string MY_NAME = "";
	std::string MY_ADDRESS = "";
	int			MY_PORT = -1;						//The port on which to listen for incoming data (server 0)
	SERIALIZATION_TYPE SERIAL_TYPE = undefined;
};


//wrapper for my_MSG
class protocol {

public:
	protocol(server_status * info) {
		server_info = info;
		last_message = getId();
	}

public:
	my_MSG form_reply(my_MSG msg, RFP resp);
	my_MSG error(my_MSG msg, std::string message);

private:
	std::mutex mut_msgs;
	int last_message;
	server_status* server_info;
	std::vector<my_MSG> messages_pending_reply;

	void newmsg(my_MSG);
	void cleanup();

	my_MSG replied_to(my_MSG);

	int getId() {
		return abs(int(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count()));
	}
};