#pragma once

#include "stdafx.h"
#include<thread>
#include <tchar.h>
#include <winsock2.h>
#include <fstream>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <signal.h>
#include <vector>
#include <future>
#include <mutex>
#include <regex>
#include <Ws2tcpip.h>
#include <chrono>
#include <stdexcept>

#include <types/memory.hpp>
#include <archives/portable_binary.hpp>
#include <archives/xml.hpp>