
#include "protocol.h"

my_MSG protocol::form_reply(my_MSG RFQ, RFP resp) {

	RFQ.type = "RFP";
	RFQ.response = resp;

	return RFQ;
}


//get message replied to
my_MSG protocol::replied_to(my_MSG msg) {
	my_MSG reply_to = msg;
	reply_to.id = 0;
	mut_msgs.lock();
	for (size_t i = 0; i < messages_pending_reply.size(); i++) {
		if (msg.id == messages_pending_reply[i].id) {

			reply_to = messages_pending_reply[i];
			messages_pending_reply.erase(messages_pending_reply.begin() + i);
			break;
		}
	}
	mut_msgs.unlock();

	cleanup();

	return reply_to;
}


//remove messages older than 1 minute.
void protocol::cleanup() {

	mut_msgs.lock();
	std::vector<my_MSG>::iterator it = messages_pending_reply.begin();

	while (it != messages_pending_reply.end()) {

		if ((last_message - it->id) > 60000) {

			it = messages_pending_reply.erase(it);
		}
		else ++it;
	}
	mut_msgs.unlock();
}

//push message for which we expect reply
void protocol::newmsg(my_MSG msg) {
	mut_msgs.lock();

	messages_pending_reply.push_back(msg);
	last_message = getId();

	mut_msgs.unlock();
}


my_MSG protocol::error(my_MSG msg, std::string message) {

	my_MSG error_msg;

	error_msg.type = "ERROR";
	error_msg.id = msg.id;
	error_msg.name = server_info->MY_NAME;
	error_msg.addr = msg.addr;
	error_msg.port = msg.port;
	error_msg.message = message;

	error_msg.response = msg.response;
	error_msg.request = msg.request;

	return error_msg;
}