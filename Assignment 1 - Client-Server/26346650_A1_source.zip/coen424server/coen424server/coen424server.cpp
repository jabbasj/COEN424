#include "allheaders.h"
#include "protocol.h"

#define BUFLEN 1024
//TODO: Error handling to prevent crashes due to corrupt/invalid format messages
//TODO: protocol error tolerance, i.e. if contents dmgd ask for resend (currently assuming reply has correct contents)
//TODO: set all clients' status as off when closing

void printMsg(my_MSG MSGPacket);
bool finished = false;

server_status my_status;				//my addr/port, next addr/port, clients registered & online
protocol * protocol_manager;

std::vector<my_MSG> messages_to_send;
std::vector<my_MSG> messages_received;
std::vector<my_MSG> temp;
std::mutex			mut_send;			//mutex for temp (which is a holder for messages_to_send
std::mutex			mut_recv;			//mutex for messages_received 

// My functions
void initializeConnection();
void loadServersList();
void closeServer();
void send(my_MSG);
void receive(my_MSG);
void sender();
void listener();
void getMyExternalIP();
my_MSG deserialize(char* to_deserialize);
void serialize(char* result, my_MSG to_serialize);
RFP  fetch_response(my_MSG RFQ);
void message_handler(my_MSG msg);

// Winsock structures
SOCKET s;
struct sockaddr_in server, si_send, si_recv;
int slen, recv_len;
char buf[BUFLEN];
char message[BUFLEN];
WSADATA wsa;

BOOL WINAPI ConsoleCtrlEventHandler(DWORD dwCtrlType);


int _tmain(int argc, _TCHAR* argv[])
{
	try {
		SetConsoleCtrlHandler(&ConsoleCtrlEventHandler, TRUE);
		protocol_manager = new protocol(&my_status);

		initializeConnection();
		std::thread s(sender);
		std::thread l(listener);
		s.join();
		l.join();
	}
	catch (std::exception e) {
		printf(e.what());
		closeServer();		
	}
	system("pause");
	return 0;
}


//sends all messages in temp vector, todo: change name temp
void sender() {

	try {
		while (1)
		{
			if (temp.size() > 0) {
				//printf("Sending (%d) pending messages...\n", temp.size());

				mut_send.lock();
				messages_to_send = temp;
				temp.clear();
				mut_send.unlock();
			}
			while (messages_to_send.size() > 0) {

				my_MSG msg_to_send = messages_to_send.front();

				//reply to sender
				std::wstring stemp = std::wstring(msg_to_send.addr.begin(), msg_to_send.addr.end());
				LPCWSTR sw = stemp.c_str();

				InetPton(AF_INET, sw, &si_send.sin_addr);
				si_send.sin_addr.S_un.S_addr = inet_addr(msg_to_send.addr.c_str());
				si_send.sin_port = htons(msg_to_send.port);

				msg_to_send.addr = my_status.MY_ADDRESS;
				msg_to_send.port = my_status.MY_PORT;

				serialize(message, msg_to_send);

				//printMsg(msg_to_send);

				if (sendto(s, message, BUFLEN, 0, (struct sockaddr*) &si_send, slen) == SOCKET_ERROR)
				{
					printf("sendto() failed with error code : %d\n", WSAGetLastError());
				}
				messages_to_send.erase(messages_to_send.begin());

			}

		}
	}
	catch (std::exception e) {
		throw e;
	}
}


//listens to all messages
void listener() {

	try {

		while (1) {
			std::cout << "Thread {" << my_status.MY_NAME << "} waiting for data...\n";

			//clear the buffer by filling null, it might have previously received data
			memset(buf, '\0', BUFLEN);

			//try to receive some data, timeouts after 2 seconds
			if ((recv_len = recvfrom(s, buf, BUFLEN, 0, (struct sockaddr *) &si_recv, &slen)) == SOCKET_ERROR)
			{
				printf("recvfrom() failed with error code : %d\n", WSAGetLastError());
			}

			if (recv_len > 0) {

				my_MSG received_packet; //Re-make the struct
				bool success = false;
				try {

					received_packet = deserialize(buf);

					received_packet.addr = inet_ntoa(*(struct in_addr *)&si_recv.sin_addr); //use ip from packet instead of given one because external Ip not working on local machine

					printf("\nReceived packet from %s:%d\n", inet_ntoa(si_recv.sin_addr), ntohs(si_recv.sin_port));
					//printMsg(received_packet);

					success = true;
				}
				catch (std::exception e) {
					std::cout << "Error: \n";
					printf(e.what());
					std::cout << std::endl;
					std::cout << buf << std::endl;
					success = false;
				}

				if (success) {
					std::thread rh(message_handler, received_packet);
					rh.detach();
				}
				else {
					//send error to sender
				}
			}
		}
	}
	catch (std::exception e) {
		throw e;
	}
}



//handles the packet first
void message_handler(my_MSG msg) {

	if (msg.type == "RFQ") {

		RFP resp = fetch_response(msg);

		if (resp.unit_price == -1 && resp.price_valid_period == "") {
			send(protocol_manager->error(msg, "PRODUCT NOT FOUND"));
		}
		else {
			my_MSG RPF = protocol_manager->form_reply(msg, fetch_response(msg));
			send(RPF);
		}
	}
	else {
		std::cout << "Unhandled msg type received from (" << msg.name << "@" << msg.addr << ":" << msg.port << ") - type: " << msg.type << "\n";
		std::cout << "Message: " << msg.message << "\n";
	}
}


//Query file called "products.txt" and generate quote
RFP fetch_response(my_MSG RFQ) {
	std::string file_name = "./products/" + RFQ.request.product_category + "/" + std::to_string(RFQ.request.product_number) + "/product.txt";

	std::ifstream input_file(file_name);
	RFP resp;

	std::string line;
	try {
		if (input_file.is_open()) {

			getline(input_file, line);
			std::regex r("unit_price:(.*)");
			std::smatch result;
			std::regex_match(line, result, r);

			resp.unit_price = stof(result[1]);

			getline(input_file, line);
			std::regex rr("price_valid_until:(.*)");
			std::smatch rresult;
			std::regex_match(line, rresult, rr);

			resp.price_valid_period = rresult[1];

		}
	}
	catch (...) {
		return resp;
	}

	return resp;
}



//initializes socket & related structures
//loads server and client data
void initializeConnection() {

	slen = sizeof(si_send);

	//Initialise winsock
	printf("\nInitialising Winsock...");
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Error Code : %d", WSAGetLastError());
		exit(EXIT_FAILURE);
	}
	printf("Initialised.\n");

	//Create a socket
	if ((s = socket(AF_INET, SOCK_DGRAM, 0)) == INVALID_SOCKET)
	{
		printf("Could not create socket : %d", WSAGetLastError());
	}
	printf("Socket created.\n");


	printf("Reading server list...");
	loadServersList();
	if (my_status.MY_PORT < 0 || my_status.SERIAL_TYPE == undefined)
	{
		printf("Could not read server list.\n");
		exit(EXIT_FAILURE);
	}
	//return 0; //<- this properly calls "closeServer" and updates the file...??????????????????????

	//Prepare the sockaddr_in structure
	si_send.sin_family = AF_INET;
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(my_status.MY_PORT);

	//Bind
	std::cout << "Binding...";
	if (bind(s, (struct sockaddr *)&server, sizeof(server)) == SOCKET_ERROR)
	{
		printf("Bind failed with error code : %d", WSAGetLastError());
		throw("Bind failed with error code : %d", WSAGetLastError());
	}
	std::cout << "Bind done.\n";

	//getMyExternalIP();
	// todo: automatic port. 8888 and go up, like client

	// set timeout after 2 seconds of listening
	//int iTimeout = 2000;
	//setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char *)&iTimeout, sizeof(iTimeout));
}


/*
Read serverconfig.txt, extract available port
Change status from off to on

serverconfig.txt format:
name:server0,status:off,ip:127.0.0.1,port:8888

*/
void loadServersList() {

	std::ifstream input_file("serverconfig.txt");
	std::ofstream output_file("temp.txt");

	std::string line;
	try {
		if (input_file.is_open()) {

			while (getline(input_file, line)) {

				if (my_status.MY_PORT < 0) {
					if (line.find("status:on") != std::string::npos) {
						output_file << line + "\n";
						continue;
					}
					else if (line.find("status:off") != std::string::npos) {
						// Extract port
						my_status.MY_NAME = line.substr(line.find("name:") + std::strlen("name:"), line.find(",status:") - line.find("name:") - std::strlen("name:"));

						my_status.MY_PORT = std::stoi(line.substr(line.find("port:") + std::strlen("port:"), line.find(",serial") - line.find("port:") - std::strlen("port:")));

						my_status.MY_ADDRESS = line.substr(line.find("ip:") + std::strlen("ip:"), line.find(",port") - line.find("ip:") - std::strlen("ip:"));

						std::string serial_type = line.substr(line.find("serial:") + std::strlen("serial:"), -1);

						if (serial_type == "xml") {
							my_status.SERIAL_TYPE = xml;
						}
						else if (serial_type == "binary") {
							my_status.SERIAL_TYPE = binary;
						}

						// Set off to on
						line.replace(line.find("status:off"), std::strlen("status:off"), "status:on");
						output_file << line + "\n";
						continue;
					}
				}
				else {
					output_file << line + "\n";
				}
			}

			input_file.close();
			output_file.close();
			// delete the original file
			remove("serverconfig.txt");
			// rename old to new
			rename("temp.txt", "serverconfig.txt");
			//remove("temp.txt");
			std::cout << "Server loaded: " << my_status.MY_NAME << " [" << my_status.MY_ADDRESS << ":" << my_status.MY_PORT << "]\n";

			std::string title = "Server: " + my_status.MY_NAME + " (" + my_status.MY_ADDRESS + ":" + std::to_string(my_status.MY_PORT) + ") - Serialization: ";

			if (my_status.SERIAL_TYPE == xml)  {
				std::cout << "Serialization: XML\n";
				title += "XML";
			}
			else if (my_status.SERIAL_TYPE == binary) {
				std::cout << "Serialization: Binary\n";
				title += "Binary";
			}
			else {
				std::cout << "Serialization: UNDEFINED!\n";
				title += "UNDEFINED!";
			}
			SetConsoleTitle(std::wstring(title.begin(), title.end()).c_str());
		}
	}
	catch (std::exception e) {
		throw e;
	}
}


//sets status back to off
void closeServer() {

	std::cout << "\nTerminating...\n";

	closesocket(s);
	WSACleanup();

	std::ifstream input_file("serverconfig.txt");
	std::ofstream output_file("temp.txt");

	std::string line;
	if (input_file.is_open()) {

		while (getline(input_file, line)) {

			if (line.size() > 0) {

				if (line.find(my_status.MY_ADDRESS) != std::string::npos && my_status.MY_PORT == std::stoi(line.substr(line.find("port:") + std::strlen("port:"), -1))) {
					line.replace(line.find("on"), std::strlen("on"), "off");
				}

				output_file << line + "\n";
			}
		}

		input_file.close();
		output_file.close();
		// delete the original file
		std::remove("serverconfig.txt");
		// rename old to new
		std::rename("temp.txt", "serverconfig.txt");
	}
}


//cout my_MSG
void printMsg(my_MSG msgPacket)
{
	std::cout << "type::" << msgPacket.type << std::endl;
	std::cout << "id::" << msgPacket.id << std::endl;
	std::cout << "port::" << msgPacket.port << std::endl;
	std::cout << "addr::" << msgPacket.addr << std::endl;
	std::cout << "name::" << msgPacket.name << std::endl;

	if (msgPacket.type == "ERROR") {
		std::cout << "msg::" << msgPacket.message << std::endl;
	}

	if (msgPacket.type == "RFP") {
		std::cout << "unit_price::" << msgPacket.response.unit_price << " -- " << "price_valid_period::" << msgPacket.response.price_valid_period << std::endl;
	}

	if (msgPacket.type == "RFQ") {
		std::cout << "acc_id::" << msgPacket.request.account_id << " -- " << "product_category::" << msgPacket.request.product_category << " -- " << "product_#::" << msgPacket.request.product_number << " -- " << "qty::" << msgPacket.request.quantity << std::endl;
	}
}

//locks mut_send ,pushes message into queue to be sent
void send(my_MSG msg) {
	mut_send.lock();
	temp.push_back(msg);
	mut_send.unlock();
}

void receive(my_MSG msg) {
	mut_recv.lock();
	messages_received.push_back(msg);
	mut_recv.unlock();
}


//unexpected exit handler
//calls closeServer when you X out
BOOL WINAPI ConsoleCtrlEventHandler(DWORD dwCtrlType)
{
	switch (dwCtrlType)
	{
	case CTRL_C_EVENT:
		closeServer();
		return FALSE;
	case CTRL_BREAK_EVENT:
		closeServer();
		// Do nothing.
		// To prevent other potential handlers from
		// doing anything, return TRUE instead.
		return FALSE;

	case CTRL_CLOSE_EVENT:
		closeServer();
		//MessageBox(NULL, L"You clicked the 'X' in the console window! Ack!", L"I'm melting!", MB_OK | MB_ICONINFORMATION);
		return FALSE;

	case CTRL_LOGOFF_EVENT:
		closeServer();
		return FALSE;
	case CTRL_SHUTDOWN_EVENT:
		// Please be careful to read the implications of using
		// each one of these, and the applicability to your
		// code. Unless you are writing a Windows Service,
		// chances are you only need to pay attention to the
		// CTRL_CLOSE_EVENT type.
		closeServer();
		return FALSE;
	}
	closeServer();
	// If it gets this far (it shouldn't), do nothing.
	return FALSE;
}


//deserialize given buffer into a my_MSG
my_MSG deserialize(char* to_deserialize) {

	my_MSG result;

	try {

		if (my_status.SERIAL_TYPE == xml) {

			std::stringstream ss; // any stream can be used	
			ss.write(to_deserialize, BUFLEN);

			cereal::XMLInputArchive iarchive(ss);// Create an output archive

			iarchive(result);

		}
		else { //default to binary

			std::stringstream ss; // any stream can be used	
			ss.write(to_deserialize, BUFLEN);

			cereal::PortableBinaryInputArchive iarchive(ss);// Create an output archive

			iarchive(result);

		}

	}
	catch (std::exception e) {
		throw e;
		return result;
	}

	return result;
}


//serialize a my_MSG into a buffer
void serialize(char* result, my_MSG to_serialize) {

	try {

		if (my_status.SERIAL_TYPE == xml) {

			std::stringstream ss; // any stream can be used	
			{
				cereal::XMLOutputArchive  oarchive(ss);// Create an output archive

				oarchive(to_serialize);
			}

			ss.read(result, BUFLEN);
	
		}
		else { //default to binary

			std::stringstream ss; // any stream can be used	
			cereal::PortableBinaryOutputArchive oarchive(ss);// Create an output archive

			oarchive(to_serialize);

			ss.read(result, BUFLEN);

		}
	}
	catch (std::exception e) {
		throw e;
	}
}