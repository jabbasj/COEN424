#include "allheaders.h"

#define MAX_MESSAGE_LENGTH 140

//structs to be serialized/deserialized
struct RFQ //request for quote
{
	int			account_id = -1;
	int			product_number = -1;
	std::string product_category = "";
	int			quantity = -1;

	template <class Archive>
	void serialize(Archive & ar)
	{
		ar(account_id, product_number, product_category, quantity);
	}
};

struct RFP //response for price
{
	float		unit_price = -1;
	std::string	price_valid_period = "";

	template <class Archive>
	void serialize(Archive & ar)
	{
		ar(unit_price, price_valid_period);
	}
};


struct my_MSG
{
	std::string type = "";
	int			id = -1;
	int			port = -1;
	std::string addr = "";
	std::string name = "";
	std::string message = "";

	RFQ			request;
	RFP			response;

	template <class Archive>
	void serialize(Archive & ar)
	{
		ar(type, id, port, addr, name, message, request, response);
	}
};

enum SERIALIZATION_TYPE { binary, xml, undefined };


struct client_status
{
	std::string MY_NAME = "";
	int			ACCOUNT_ID = -1;
	std::string SERVER_ADDRESS = "";
	int			SERVER_PORT = -1;
	int			SERVER_PORT_BINARY = -1;
	int			SERVER_PORT_XML = -1;
	std::string MY_ADDRESS = "";
	int			MY_PORT = -1;			// port attempted, increment by 1 until bind works
	SERIALIZATION_TYPE SERIAL_TYPE = undefined;
};


//wrapper for my_MSG
class protocol {

public:
	protocol(client_status * info) {
		client_info = info;
		last_message = getId();
	}

	my_MSG form_request(int product_num, std::string product_cat, int qty);
	my_MSG ack(my_MSG msg);

	bool replied(my_MSG);
	my_MSG replied_to(my_MSG);
	my_MSG error(my_MSG msg, std::string message);
	std::vector<my_MSG> timed_out_msgs();
	bool cleanup();
	void erase_all();

private:
	std::mutex mut_msgs;
	int last_message;
	client_status* client_info;
	std::vector<my_MSG> messages_pending_reply;
	void new_msg(my_MSG);

	// returns unique id: time_since_epoch in milliseconds
	int getId() {
		return abs(int(std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count()));
	}

};